#
# Cookbook:: nexus3
#
# Copyright:: Copyright (c) 2017-present Sonatype, Inc. All rights reserved.

# frozen_string_literal: true
require 'chefspec'
require 'chefspec/berkshelf'
